import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import TimePicker from 'react-time-picker';
import "react-datepicker/dist/react-datepicker.css";
import './App.css';



class Task extends Component {
    constructor(props) {
        super(props);
        this.state = {
            taskName: '', taskDesc: '',
            taskList: localStorage.getItem('taskList') == null ? [] : JSON.parse(localStorage.getItem('taskList')),
            viewAll: false,
            startDate: new Date(),
            time: ''
        };
        this.getTaskName = this.getTaskName.bind(this);
        this.getTaskDesc = this.getTaskDesc.bind(this);
        this.createTask = this.createTask.bind(this);
        this.toggleViewAll = this.toggleViewAll.bind(this);
        this.toggleView3 = this.toggleView3.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.onChange = this.onChange.bind(this);

    }

    handleChange(date) {
        this.setState({
            startDate: date
        });
    }
    onChange(time){
        this.setState({
            time: time
        });   
    } 

    getTaskName(e) {
        this.setState({ taskName: e.target.value });
    }

    getTaskDesc(e) {
        this.setState({ taskDesc: e.target.value });
    }

    createTask(e) {
        if (this.state.taskName != '') {
            alert(`${this.state.taskName} Task Created for ${this.state.taskDesc}`)
            this.state.taskList.push({
                taskN: this.state.taskName,
                taskD: this.state.taskDesc,
                time: this.state.time 
            })
            localStorage.setItem('taskList', JSON.stringify(this.state.taskList));

            this.setState({
                taskName: '',
                taskDesc: ''
            });
        } else {
            alert('Please Enter Mandatory data.')
        }

    }


    toggleViewAll() {
        this.setState({ viewAll: true })
    }

    toggleView3() {
        this.setState({ viewAll: false })
    }

    render() {
        return (
            <div className='outerDiv'>
                <div className='div1'>
                    <h3>TASK CREATOR</h3>
                    <div>Task Name</div>
                    <input type='text' className='ip' value={this.state.taskName} onChange={this.getTaskName}></input>
                    <div>Task Description(Optional)</div>
                    <input type='text' className='ip' value={this.state.taskDesc} onChange={this.getTaskDesc}></input>
                    <div className='outerDiv'>
                        Select Date:
                        <DatePicker
                            selected={this.state.startDate}
                            onChange={this.handleChange}
                        />
                        Select Time:
                        <TimePicker
                            onChange={this.onChange}
                            value={this.state.time}
                        />
                    </div>
                    <button className='btn bt' onClick={this.createTask}>Create Task</button>
                </div>
                <div className='div2'>
                    <div className='header'>
                        <button className='btn ip' onClick={this.toggleView3}>Upcoming</button>
                        <button className='btn ip' onClick={this.toggleViewAll}>All</button>
                    </div>
                    <div className='list'>
                        <List data={this.state.taskList} flag={this.state.viewAll} />
                    </div>
                </div>
            </div>
        );
    }

}



export default Task;


function List(props) {
    var data = '';
    if (localStorage.getItem('taskList') !== null) {
        data = JSON.parse(localStorage.getItem('taskList'));
    } else {
        data = props.data;
    }
    let list = [];
    if (props.flag === true) {
        list = data.map((elem, i) => <div key={i} className='ls'> {elem.taskN}  {elem.time}</div>)
    } else {
        let tempData = data.slice(0, 3);
        list = tempData.map((elem, i) => <div key={i} className='ls'>{elem.taskN}  {elem.time}</div>)
    }
    return <div>{list}</div>;
}



